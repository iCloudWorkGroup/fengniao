define(function() {
	'use strict';
	var highlight;
	highlight = {
		highlightStart: function() {
			//触发cellsContainer监听mouseover事件
			//阻止默认选中事件
			//监听mouse事件,返回(鼠标容器内位置，视图浏览器可视区域相对位置)
		},
		highlightStop: function() {
			//停止监听
			//删除模型
		},
		newLightView: function() {
			//获取相对
		},
		getLightDirection: function() {

		}
	};
	return highlight;
});