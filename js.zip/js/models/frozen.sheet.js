
// (function() {
//     'use strict';
//     app.Models.FrozenSheet = Backbone.Model.extend({
//         defaults: {
//             state: false,
//             rowIndex: 0,
//             colIndex: 0
//         }
//     });
// })();